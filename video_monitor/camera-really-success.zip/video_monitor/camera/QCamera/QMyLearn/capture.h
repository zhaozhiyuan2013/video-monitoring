#ifndef CAPTURE_H
#define CAPTURE_H

class capture
{
public:
    capture();
};

#endif // CAPTURE_H
