#include "ab.h"


bool ab::present ( const QVideoFrame & frame ) {
 // QVideoSurfaceFormat aaaaaa = surfaceFormat();
 if (frame.isValid()) {}
  return true;
}
