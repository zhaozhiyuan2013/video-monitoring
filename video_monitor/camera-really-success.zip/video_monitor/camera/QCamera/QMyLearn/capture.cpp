#include "capture.h"

capture::capture()
{
}
