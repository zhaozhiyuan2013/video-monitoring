#include "thread1.h"

thread1::thread1(QObject *parent) :
    QThread(parent)
{
}


void thread1::run(){
    while(1) {

    }
}
